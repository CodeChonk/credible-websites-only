local_blockUrl = chrome.runtime.getURL("/assets/blocked.html"); //"chrome-extension://biaebfghcnpflmfagkahlfgfgbikmldk/assets/blocked.html"
window.location.replace(local_blockUrl);